#include "Partida.h"
#include "Escenario.h"
#include "Entidad.h"
#include "Posicion.h"
#include "Unidad.h"


Partida::Partida(void)
{
}


Partida::~Partida(void)
{
}


void Partida::avanzarFrame(void){
}


void Partida::crearEntidad(Entidad entidad, Posicion pos){
}

