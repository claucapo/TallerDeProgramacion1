#include "Jugador.h"
#include "Entidad.h"
#include "Unidad.h"

Jugador::Jugador(void)
{
# 
}


Jugador::~Jugador(void)
{
}


bool Jugador::poseeEntidad(Entidad entidad)
{
	return false;
}


void Jugador::agregarEntidad(Entidad entidad)
{
}


void Jugador::quitarEntidad(Entidad entidad)
{
}


void Jugador::quitarEntidad(Posicion pos)
{
}
