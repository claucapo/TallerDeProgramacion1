#ifndef TEST_H
#define	TEST_H

// From EscenarioTest.cpp
void testEscenarioBasico();

#endif